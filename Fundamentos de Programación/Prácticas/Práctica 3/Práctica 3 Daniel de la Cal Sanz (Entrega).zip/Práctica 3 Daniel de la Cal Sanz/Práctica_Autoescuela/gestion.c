#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "gestion.h"

void Titulo(char *titulo){
    printf("***********\n");
    printf("* %s\n", titulo);
    printf("***********\n\n");
}

//Usuarios
void anadirUsuario(char *datos, char *tipo){
    char copia[MAX_LINEA];
    strcpy(copia, datos);

    char *dni = strtok(copia, ";");
    char *apellidos = strtok(NULL, ";");
    char *nombre = strtok(NULL, ";");

    if (dni == NULL) dni = "Sin DNI";
    if (apellidos == NULL) apellidos = "Sin Apellidos";
    if (nombre == NULL) nombre = "Sin Nombre";

    if (apellidos[0] == ' ') apellidos++;
    if (nombre[0] == ' ') nombre++;

    FILE *fichero = fopen("usuarios.csv", "a");
    if (fichero == NULL){
        printf("Error al abrir usuarios.csv\n");
        return;
    }

    fprintf(fichero, "%s; %s; %s; %s\n", dni, apellidos, nombre, tipo);
    fclose(fichero);

    Titulo("ANADIR USUARIO");
    printf("DNI: %s\nAPELLIDOS: %s\nNOMBRE: %s\n", dni, apellidos, nombre);
    printf("Se anadio con exito\n");
}

void editarUsuario(char *datos, char *tipo){
    char copia[MAX_LINEA];
    strcpy(copia, datos);
    char *dni = strtok(copia, ";");

    borrarUsuario(dni, tipo);

    anadirUsuario(datos, tipo);
}

void borrarUsuario(char *dni, char *tipo){
    FILE *f = fopen("usuarios.csv", "r");
    FILE *temp = fopen("temp.csv", "w");
    char linea[MAX_LINEA];
    int encontrado = 0;
    char d[MAX_DNI], a[MAX_TEXTO], n[MAX_TEXTO];

    if (f == NULL || temp == NULL) return;

    while (fgets(linea, MAX_LINEA, f) != NULL){
        char lineaCopia[MAX_LINEA];
        strcpy(lineaCopia, linea);

        int largo = strlen(lineaCopia);
        if (largo > 0 && lineaCopia[largo-1] == '\n'){
            lineaCopia[largo-1] = '\0';
        }

        char *ptrDni = strtok(lineaCopia, ";");
        char *ptrApellido = strtok(NULL, ";");
        char *ptrNombre = strtok(NULL, ";");

        if (ptrDni != NULL && strcmp(ptrDni, dni) == 0){
            encontrado = 1;
            strcpy(d, ptrDni);
            if (ptrApellido) strcpy(a, ptrApellido);
            if (ptrNombre) strcpy(n, ptrNombre);
        }
        else{
            fprintf(temp, "%s", linea);
        }
    }

    fclose(f);
    fclose(temp);

    remove("usuarios.csv");
    rename("temp.csv", "usuarios.csv");

    if (encontrado == 1){
        Titulo("ELIMINAR USUARIO");
        printf("DNI: %s\nAPELLIDOS: %s\nNOMBRE: %s\n", d, a, n);
        printf("Se elimino con exito\n");
    }
    else{
        printf("No se encontro el usuario con ese DNI\n");
    }
}

//Pr�cticas
void anadirPractica(char *dniAlumno, char *dia, char *hora, char *dniProfesor){
    FILE *f = fopen("practicas.csv", "a");
    if (f == NULL) return;

    fprintf(f, "%s;%s;%s;%s\n", dia, hora, dniAlumno, dniProfesor);
    fclose(f);

    Titulo("ANADIR PRACTICA");
    printf("ALUMNO: %s\nDIA: %s\nHORA: %s\nPROFESOR: %s\n", dniAlumno, dia, hora, dniProfesor);
    printf("Se anadio con exito\n");
}

void borrarPractica(char *dniAlumno, char *dia, char *hora, char *dniProfesor){
    FILE *f = fopen("practicas.csv", "r");
    FILE *temp = fopen("temp_practicas.csv", "w");
    char linea[MAX_LINEA];
    int encontrado = 0;

    char d[20], h[10], a[MAX_DNI], p[MAX_DNI];

    if (f == NULL || temp == NULL) return;

    while (fgets(linea, MAX_LINEA, f) != NULL){
        char lineaOriginal[MAX_LINEA];
        strcpy(lineaOriginal, linea);

        char copia[MAX_LINEA];
        strcpy(copia, linea);

        int largo = strlen(copia);
        if (largo > 0 && copia[largo-1] == '\n'){
            copia[largo-1] = '\0';
        }

        char *ptrD = strtok(copia, ";");
        char *ptrH = strtok(NULL, ";");
        char *ptrA = strtok(NULL, ";");
        char *ptrP = strtok(NULL, ";");

        if (ptrD == NULL) ptrD = "?";
        if (ptrH == NULL) ptrH = "?";
        if (ptrA == NULL) ptrA = "?";
        if (ptrP == NULL) ptrP = "?";

        if (ptrD && ptrH && ptrA && ptrP && strcmp(ptrD, dia) == 0 && strcmp(ptrH, hora) == 0 && strcmp(ptrA, dniAlumno) == 0 && strcmp(ptrP, dniProfesor) == 0){
            encontrado = 1;
            strcpy(d, ptrD);
            strcpy(h, ptrH);
            strcpy(a, ptrA);
            strcpy(p, ptrP);
        }
        else{
            fprintf(temp, "%s", lineaOriginal);
        }
    }

    fclose(f);
    fclose(temp);

    remove("practicas.csv");
    rename("temp_practicas.csv", "practicas.csv");

    if (encontrado) {
        Titulo("ELIMINAR PRACTICA");
        printf("ALUMNO: %s\nDIA: %s\nHORA: %s\nPROFESOR: %s\n", a, d, h, p);
        printf("Se elimino con exito\n");
    } else{
        printf("No se encontro la practica.\n");
    }
}

//Examenes
void anadirExamen(char *dniAlumno, char *dia, char *hora){
    FILE *f = fopen("examenes.csv", "a");
    if (f == NULL) return;

    fprintf(f, "%s;%s;%s\n", dia, hora, dniAlumno);
    fclose(f);

    Titulo("ANADIR EXAMEN");
    printf("ALUMNO: %s\nDIA: %s\nHORA: %s\n", dniAlumno, dia, hora);
    printf("Se anadio con exito\n");
}

void borrarExamen(char *dniAlumno, char *dia, char *hora){
    FILE *f = fopen("examenes.csv", "r");
    FILE *temp = fopen("temp_examenes.csv", "w");
    char linea[MAX_LINEA];
    int encontrado = 0;

    char d[20], h[10], a[MAX_DNI];

    if (f == NULL || temp == NULL) return;

    while (fgets(linea, MAX_LINEA, f) != NULL){
        char lineaOriginal[MAX_LINEA];
        strcpy(lineaOriginal, linea);

        char copia[MAX_LINEA];
        strcpy(copia, linea);

        int largo = strlen(copia);
        if (largo > 0 && copia[largo-1] == '\n'){
            copia[largo-1] = '\0';
        }

        char *ptrD = strtok(copia, ";");
        char *ptrH = strtok(NULL, ";");
        char *ptrA = strtok(NULL, ";");

        if (ptrD == NULL) ptrD = "?";
        if (ptrH == NULL) ptrH = "?";
        if (ptrA == NULL) ptrA = "?";

        if (ptrD && ptrH && ptrA && strcmp(ptrD, dia) == 0 && strcmp(ptrH, hora) == 0 && strcmp(ptrA, dniAlumno) == 0){
            encontrado = 1;
            strcpy(d, ptrD);
            strcpy(h, ptrH);
            strcpy(a, ptrA);
        }
        else{
            fprintf(temp, "%s", lineaOriginal);
        }
    }

    fclose(f);
    fclose(temp);

    remove("examenes.csv");
    rename("temp_examenes.csv", "examenes.csv");

    if (encontrado){
        Titulo("ELIMINAR EXAMEN");
        printf("ALUMNO: %s\nDIA: %s\nHORA: %s\n", a, d, h);
        printf("Se elimino con exito\n");
    }
    else{
        printf("No se encontro el examen.\n");
    }
}

//Listados
void listarUsuarios(char *tipo, char *filtrarApellido, char *filtrarNombre) {
    FILE *f = fopen("usuarios.csv", "r");
    char linea[MAX_LINEA];

    if (f == NULL){
        printf("No hay fichero de usuarios.\n");
        return;
    }

    Titulo("LISTADO USUARIOS");

    while (fgets(linea, MAX_LINEA, f) != NULL){
        int largo = strlen(linea);
        if (largo > 0 && linea[largo-1] == '\n'){
            linea[largo-1] = '\0';
        }

        char copia[MAX_LINEA];
        strcpy(copia, linea);

        char *dni = strtok(copia, ";");
        char *ape = strtok(NULL, ";");
        char *nom = strtok(NULL, ";");
        char *tip = strtok(NULL, ";");

        if (dni && ape && nom && tip){
            if (ape[0] == ' ') ape++;
            if (nom[0] == ' ') nom++;
            if (tip[0] == ' ') tip++;

            if (strcmp(tip, tipo) == 0){
                int mostrar = 1;
                if (filtrarApellido != NULL && strstr(ape, filtrarApellido) == NULL) mostrar = 0;
                if (filtrarNombre != NULL && strstr(nom, filtrarNombre) == NULL) mostrar = 0;

                if (mostrar == 1){
                    printf("%s\t%s\t%s\n", dni, ape, nom);
                }
            }
        }
    }
    fclose(f);
}

void listarPracticas(char *filtrarDia, char *filtrarHora){
    FILE *f = fopen("practicas.csv", "r");
    char linea[MAX_LINEA];

    if (f == NULL){
        printf("No hay fichero de practicas.\n");
        return;
    }

    Titulo("LISTADO PRACTICAS");

    while (fgets(linea, MAX_LINEA, f) != NULL){
        int largo = strlen(linea);
        if (largo > 0 && linea[largo-1] == '\n'){
            linea[largo-1] = '\0';
        }

        char copia[MAX_LINEA];
        strcpy(copia, linea);

        char *d = strtok(copia, ";");
        char *h = strtok(NULL, ";");
        char *alu = strtok(NULL, ";");
        char *prof = strtok(NULL, ";");

        if (d && h && alu){
            int mostrar = 1;
            if (filtrarDia != NULL && strcmp(d, filtrarDia) != 0) mostrar = 0;
            if (filtrarHora != NULL && strcmp(h, filtrarHora) != 0) mostrar = 0;

            if (mostrar == 1){
                if (prof != NULL){
                    printf("%s %s\t%s\tP: %s\n", d, h, alu, prof);
                }
                else{
                    printf("%s %s\t%s\tP: No disponible\n", d, h, alu);
                }
            }
        }
    }
    fclose(f);
}

void listarExamenes(char *filtrarDia, char *filtrarHora){
    FILE *f = fopen("examenes.csv", "r");
    char linea[MAX_LINEA];

    if (f == NULL){
        printf("No hay fichero de examenes.\n");
        return;
    }

    Titulo("LISTADO EXAMENES");

    while (fgets(linea, MAX_LINEA, f) != NULL){
        int largo = strlen(linea);
        if (largo > 0 && linea[largo-1] == '\n'){
            linea[largo-1] = '\0';
        }

        char copia[MAX_LINEA];
        strcpy(copia, linea);

        char *d = strtok(copia, ";");
        char *h = strtok(NULL, ";");
        char *alu = strtok(NULL, ";");

        if (d && h && alu){
            int mostrar = 1;
            if (filtrarDia != NULL && strcmp(d, filtrarDia) != 0) mostrar = 0;
            if (filtrarHora != NULL && strcmp(h, filtrarHora) != 0) mostrar = 0;

            if (mostrar == 1){
                printf("%s %s\t%s\n", d, h, alu);
            }
        }
    }
    fclose(f);
}
